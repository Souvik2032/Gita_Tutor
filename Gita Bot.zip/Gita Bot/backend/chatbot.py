import re
import json
import pandas as pd
from sentence_transformers import SentenceTransformer, util
import torch
import requests

class BhagavadGitaChatbot:
    def __init__(self, csv_path):
        # Load the dataset (ensure your CSV columns match these names)
        self.data = pd.read_csv(csv_path)
        
        # Initialize the SentenceTransformer model
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # Precompute embeddings for the 'EngMeaning' column
        embeddings_list = [
            self.model.encode(text, convert_to_tensor=True)
            for text in self.data['EngMeaning']
        ]
        self.embeddings = torch.stack(embeddings_list)

    def get_direct_verse_response(self, query):
        """
        Attempt to extract chapter and verse numbers from the query using regex.
        If found, filter the dataset and return the matching row.
        """
        pattern = re.compile(r"chapter\s*(\d+).*verse\s*(\d+)", re.IGNORECASE)
        match = pattern.search(query)
        if match:
            chapter_num = match.group(1)
            verse_num = match.group(2)
            filtered = self.data[
                (self.data['Chapter'].astype(str) == chapter_num) &
                (self.data['Verse'].astype(str) == verse_num)
            ]
            if not filtered.empty:
                verse_data = filtered.iloc[0]
                response_text = (
                    f"ID: {verse_data['ID']}\n"
                    f"Chapter: {verse_data['Chapter']}\n"
                    f"Verse: {verse_data['Verse']}\n\n"
                    f"Shloka:\n{verse_data['Shloka']}\n\n"
                    f"Transliteration:\n{verse_data['Transliteration']}\n\n"
                    f"English Meaning:\n{verse_data['EngMeaning']}\n\n"
                    f"Hindi Meaning:\n{verse_data['HinMeaning']}\n\n"
                    f"Word-by-Word Explanation:\n{verse_data['WordMeaning']}"
                )
                return response_text
        return None

    def fallback_openrouter_response(self, query):
        """
        Call the Open Router API (using the free DeepSeek R1 Distill Llama 70B model)
        to address general queries.
        """
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": "Bearer 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",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:5000",
            "X-Title": "Geeta Guidance Chatbot"
        }
        payload = {
            "model": "deepseek/deepseek-r1-distill-llama-70b:free",
            "messages": [
                {
                    "role": "user",
                    "content": query
                }
            ]
        }
        try:
            response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=10)
            if response.status_code == 200:
                json_data = response.json()
                answer = json_data.get("choices", [{}])[0].get("message", {}).get("content", "")
                if answer:
                    return answer.strip()
                else:
                    return "Sorry, I did not get a proper response from the AI service."
            else:
                return "Sorry, I couldn't fetch an answer from the Open Router API."
        except Exception as e:
            return f"Error while calling Open Router API: {str(e)}"

    def get_response(self, query):
        lower_query = query.lower()
        # If query contains both "chapter" and "verse", try direct lookup first.
        if "chapter" in lower_query and "verse" in lower_query:
            direct_response = self.get_direct_verse_response(query)
            if direct_response:
                return direct_response

        # If query seems related to verse/chapter (contains digits), use similarity search.
        if "chapter" in lower_query or "verse" in lower_query or any(char.isdigit() for char in lower_query):
            query_embedding = self.model.encode(query, convert_to_tensor=True)
            if query_embedding.dim() == 1:
                query_embedding = query_embedding.unsqueeze(0)
            cosine_scores = util.cos_sim(query_embedding, self.embeddings)[0]
            top_idx = int(torch.argmax(cosine_scores))
            verse_data = self.data.iloc[top_idx]
            response_text = (
                f"ID: {verse_data['ID']}\n"
                f"Chapter: {verse_data['Chapter']}\n"
                f"Verse: {verse_data['Verse']}\n\n"
                f"Shloka:\n{verse_data['Shloka']}\n\n"
                f"Transliteration:\n{verse_data['Transliteration']}\n\n"
                f"English Meaning:\n{verse_data['EngMeaning']}\n\n"
                f"Hindi Meaning:\n{verse_data['HinMeaning']}\n\n"
                f"Word-by-Word Explanation:\n{verse_data['WordMeaning']}"
            )
            return response_text
        else:
            # For general queries outside the dataset, use the Open Router API.
            answer = self.fallback_openrouter_response(query)
            return f"According to Open Router:\n{answer}"

# Standalone testing:
if __name__ == "__main__":
    chatbot = BhagavadGitaChatbot("Bhagwad_Gita.csv")
    test_queries = [
        "How to lead a healthy life?",
        "Who is the conqueror of worlds?",
        "What is Bhagavad Gita about?",
        "Chapter 2 Verse 47"
    ]
    for q in test_queries:
        print("Query:", q)
        print("Response:", chatbot.get_response(q))
        print("-----")
