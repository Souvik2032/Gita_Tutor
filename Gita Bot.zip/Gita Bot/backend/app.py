from flask import Flask, request, jsonify, send_from_directory
from chatbot import BhagavadGitaChatbot
import os

app = Flask(__name__, static_folder="../", template_folder="../")

# Initialize the chatbot with the dataset
chatbot = BhagavadGitaChatbot("Bhagwad_Gita.csv")

@app.route("/")
def index():
    # Serve index.html from the parent folder
    return send_from_directory("../", "index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "")
    response_text = chatbot.get_response(user_message)
    return jsonify({"response": response_text})

# Catch-all route to serve any static file (including solution.html, etc.)
@app.route("/<path:filename>")
def serve_static(filename):
    # This will serve any file from the parent directory (your project root)
    return send_from_directory("../", filename)

if __name__ == "__main__":
    app.run(debug=True)
