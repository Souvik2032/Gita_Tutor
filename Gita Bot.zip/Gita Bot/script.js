// script.js
console.log("Geeta Guidance website is active!");
